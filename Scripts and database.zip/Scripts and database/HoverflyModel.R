
####### Hoverfly data
data1<-read.csv("D:/Side projects/Peucetia/Analysis/ModelHover1.csv")

str(data1)
library(car)
library(lme4)
library(ggplot2)

data1$distance <- as.factor(data1$distance)
data1$flower <- as.factor(data1$flower)
str(data1)

###Luminance contrast model####

MH_LC <- lmer(LC ~ distance + flower + (1 | individual), data = data1)
summary(MH_LC)
anova(MH_LC)
Anova(MH_LC)

plot(residuals(MH_LC), fitted(MH_LC), main = "Residuos vs Valores Ajustados")
shapiro.test(residuals(MH_LC, type = "deviance"))
qqnorm(residuals(MH_LC, type = "deviance"))
qqline(residuals(MH_LC, type = "deviance"), col = "red")
hist(residuals(MH_LC, type = "deviance"), main = "Histogram of Residuals", xlab = "Residuals")

ggplot(data1, aes(x = flower, y = LC, color = distance)) +
  geom_boxplot() +
  theme_minimal()

# Create results dataframe
fixed_effects_LC <- data.frame(
  Estimate = c(7.3389, -0.0781, -0.1716, -2.8046),
  StdError = c(0.2543, 0.2059, 0.2059, 0.1681),
  t_value = c(28.856, -0.379, -0.833, -16.679)
)

# Estimate p-values
fixed_effects_LC$p_value <- 2 * (1 - pnorm(abs(fixed_effects_LC$t_value)))

# Print p-values table
print(fixed_effects_LC)

###Chromatic contrast model####
MH_CC <- lmer(CC ~ distance + flower + (1 | individual), data = data1)
summary(MH_CC)
anova(MH_CC)
Anova(MH_CC)

ggplot(data1, aes(x = flower, y = CC, color = distance)) +
  geom_boxplot() +
  theme_minimal()

plot(residuals(MH_CC), fitted(MH_CC), main = "Residuos vs Valores Ajustados")
shapiro.test(residuals(MH_CC, type = "deviance"))
qqnorm(residuals(MH_CC, type = "deviance"))
qqline(residuals(MH_CC, type = "deviance"), col = "red")
hist(residuals(MH_CC, type = "deviance"), main = "Histogram of Residuals", xlab = "Residuals")


# Create results dataframe
fixed_effects_CC <- data.frame(
  Estimate = c(2.8404, -0.1256, -0.1953, 3.5131),
  StdError = c(0.2200, 0.1700, 0.1700, 0.1388),
  t_value = c(12.910, -0.739, -1.149, 25.316)
)

# Estimate p-values
fixed_effects_CC$p_value <- 2 * (1 - pnorm(abs(fixed_effects_CC$t_value)))

# Print p-values table
print(fixed_effects_CC)


###Chromatic Kurtosis Model####

MH_KC <- lmer(KC ~ distance + flower + (1 | individual), data = data1)
summary(MH_KC)
anova(MH_KC)
Anova(MH_KC)

plot(residuals(MH_KC), fitted(MH_KC), main = "Residuos vs Valores Ajustados")
shapiro.test(residuals(MH_KC, type = "deviance"))
qqnorm(residuals(MH_KC, type = "deviance"))
qqline(residuals(MH_KC, type = "deviance"), col = "red")
hist(residuals(MH_KC, type = "deviance"), main = "Histogram of Residuals", xlab = "Residuals")

###Chromatic Kurtosis log transformation###

data1$KC_log <- log(data1$KC + 1)
MH_KC_log <- lmer(KC_log ~ distance + flower + (1 | individual), data = data1)
summary(MH_KC_log)
anova(MH_KC_log)
Anova(MH_KC_log)

plot(residuals(MH_KC_log), fitted(MH_KC_log), main = "Residuos vs Valores Ajustados")
shapiro.test(residuals(MH_KC_log, type = "deviance"))
hist(residuals(MH_KC_log, type = "deviance"), main = "Histogram of Residuals", xlab = "Residuals")


# Create results dataframe
fixed_effects_KC <- data.frame(
  Estimate = c(4.06094, -0.31761, -0.65029, -1.20430),
  StdError = c(0.15549, 0.07961, 0.07961, 0.06500),
  t_value = c(26.118, -3.990, -8.168, -18.527)
)

# Estimate p-values
fixed_effects_KC$p_value <- 2 * (1 - pnorm(abs(fixed_effects_KC$t_value)))

# Print p-values table
print(fixed_effects_KC)

###Luminance Kurtosis model####

MH_KL <- lmer(KL ~ distance + flower + (1 | individual), data = data1)
summary(MH_KL)
anova(MH_KL)
Anova(MH_KL)

ggplot(data1, aes(x = flower, y = KL, color = distance)) +
  geom_boxplot() +
  theme_minimal()

plot(residuals(MH_KL), fitted(MH_KL), main = "Residuos vs Valores Ajustados")
shapiro.test(residuals(MH_KL, type = "deviance"))
qqnorm(residuals(MH_KL, type = "deviance"))
qqline(residuals(MH_KL, type = "deviance"), col = "red")
hist(residuals(MH_KL, type = "deviance"), main = "Histogram of Residuals", xlab = "Residuals")


# Create results dataframe
fixed_effects_KL <- data.frame(
  Estimate = c(32.0150, -12.4401, -18.8312, -0.9639),
  StdError = c(3.9306, 2.5920, 2.5920, 2.1164),
  t_value = c(8.145, -4.799, -7.265, -0.455)
)

# Estimate p-values
fixed_effects_KL$p_value <- 2 * (1 - pnorm(abs(fixed_effects_KL$t_value)))

# Print p-values table
print(fixed_effects_KL)

## Figures for the visual modelling

## Load necessary libraries
library(ggplot2)

# Create the grouped boxplot Luminance contrast
ggplot(data1, aes(x = distance, y = LC, fill = flower)) +
  geom_boxplot(position = position_dodge(width = 0.8)) +
  labs(
    x = "Distance (cm)",
    y = "Mean Luminance Contrast (MΔSL)"
  ) +
  scale_fill_manual(values = c("1" = "whitesmoke", "2" = "yellow3")) +  # Custom colors
  theme_minimal() +  # Start with a minimal theme
  theme(
    panel.grid.major = element_blank(),   # Remove major grid lines
    panel.grid.minor = element_blank(),   # Remove minor grid lines
    axis.line = element_line(colour = "black"),  # Add black axis lines
    legend.position = "none",             # Remove legend
    text = element_text(family = "Helvetica", size=11)  # Set font to Helvetica
  )

# Create the grouped boxplot Chromatic contast
ggplot(data1, aes(x = distance, y = CC, fill = flower)) +
  geom_boxplot(position = position_dodge(width = 0.8)) +
  labs(
    x = "Distance (cm)",
    y = "Mean Chromatic Contrast (MΔS)"
  ) +
  scale_fill_manual(values = c("1" = "whitesmoke", "2" = "yellow3")) +  # Custom colors
  theme_minimal() +  # Start with a minimal theme
  theme(
    panel.grid.major = element_blank(),   # Remove major grid lines
    panel.grid.minor = element_blank(),   # Remove minor grid lines
    axis.line = element_line(colour = "black"),  # Add black axis lines
    legend.position = "none",             # Remove legend
    text = element_text(family = "Helvetica", size=11)  # Set font to Helvetica
  )

# Create the grouped boxplot Luminance Kurtosis
ggplot(data1, aes(x = distance, y = KL, fill = flower)) +
  geom_boxplot(position = position_dodge(width = 0.8)) +
  labs(
    x = "Distance (cm)",
    y = "Kurtosis for edege Luminance Contrast"
  ) +
  scale_fill_manual(values = c("1" = "whitesmoke", "2" = "yellow3")) +  # Custom colors
  theme_minimal() +  # Start with a minimal theme
  theme(
    panel.grid.major = element_blank(),   # Remove major grid lines
    panel.grid.minor = element_blank(),   # Remove minor grid lines
    axis.line = element_line(colour = "black"),  # Add black axis lines
    legend.position = "none",             # Remove legend
    text = element_text(family = "Helvetica", size=11)  # Set font to Helvetica
  )

# Create the grouped boxplot Chromatic Kurtosis
ggplot(data1, aes(x = distance, y = KC, fill = flower)) +
  geom_boxplot(position = position_dodge(width = 0.8)) +
  labs(
    x = "Distance (cm)",
    y = "Kurtosis for edege Chromatic Contrast"
  ) +
  scale_fill_manual(values = c("1" = "whitesmoke", "2" = "yellow3")) +  # Custom colors
  theme_minimal() +  # Start with a minimal theme
  theme(
    panel.grid.major = element_blank(),   # Remove major grid lines
    panel.grid.minor = element_blank(),   # Remove minor grid lines
    axis.line = element_line(colour = "black"),  # Add black axis lines
    legend.position = "none",             # Remove legend
    text = element_text(family = "Helvetica", size=11)  # Set font to Helvetica
  )
